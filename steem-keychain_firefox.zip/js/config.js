let config = {
  mainNet: "ssc-mainnet1"
};
